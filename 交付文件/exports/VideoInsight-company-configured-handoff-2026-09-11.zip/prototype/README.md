# 产品原型目录

用于存放短视频批量生产系统的交互原型、页面结构说明、线框图与设计稿。

## 原型文件列表

### 已完成原型

- **decision-guide.html** - 任务决策引导界面
  - 功能：帮助用户从修Bug、加功能、代码整理三个方向中快速选择并输入具体任务需求
  - 特性：响应式设计、交互动效、表单验证、示例引导
  - 文件：`decision-guide.html`
  - 更新日期：2026-07-19

- **b2b-optimization/dashboard-prototype.html** - B2B 优化高保真 Dashboard 原型
  - 功能：面向 B 端客户的短视频数据监控与分析看板
  - 特性：高保真视觉风格、现代 UI、数据可视化、响应式设计
  - 配套文档：`b2b-optimization/README.md`、`b2b-optimization/DESIGN.md`、`b2b-optimization/COMPONENTS.md`
  - 更新日期：2026-07-19

- **optimized-v1/index.html** - 优化版原型
  - 功能：系统核心页面优化迭代版本
  - 特性：交互优化、视觉迭代
  - 更新日期：2026-07-19

- **strategy-framework-visualization.html** - 策略框架可视化原型
  - 功能：展示短视频智能生产系统的差异化定位与策略建议框架
  - 特性：响应式设计、交互动效、数据可视化、策略框架展示
  - 配套文档：`doc/strategic-positioning-proposal.md`（完整版）、`doc/strategy-executive-summary.md`（执行摘要）
  - 更新日期：2026-07-22

### 规划原型

- 首页总览原型
- 关键词管理原型
- 文案复刻工作台原型
- 数字人管理原型
- AI 剪辑工作台原型
- 一键发布原型

## 使用说明

1. 直接打开HTML文件即可查看原型
2. 所有原型均为单文件实现，包含完整的HTML、CSS和JavaScript
3. 原型支持PC、平板和手机等多种设备
4. 交互功能完整，可进行真实操作体验

## 设计规范

- 视觉风格：高保真、现代、简洁、有质感
- 配色方案：统一、层次清晰
- 交互效果：hover、active、点击反馈、过渡动画
- 响应式：自适应不同屏幕尺寸
- 代码规范：结构语义化、可维护、可扩展
